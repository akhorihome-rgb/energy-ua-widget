package ua.energy.widget

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object OutageNotifier {

    private const val CHANNEL_ID = "outage_alerts"
    private const val CHANNEL_NAME = "Сповіщення про відключення"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Попередження за N хвилин до вимкнення/увімкнення"
                enableVibration(true)
            }
            (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }

    fun scheduleNext(context: Context, widgetId: Int, periods: List<OutagePeriod>) {
        cancel(context, widgetId)
        ensureChannel(context)

        val now = System.currentTimeMillis()
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        var reqCode = 10000 + widgetId * 40

        val timers = mutableListOf<Int>()
        if (WidgetPrefs.notifyEnabled1(context, widgetId)) {
            timers.add(WidgetPrefs.notifyMinutes(context, widgetId))
        }
        if (WidgetPrefs.notifyEnabled2(context, widgetId)) {
            timers.add(WidgetPrefs.notifyMinutes2(context, widgetId))
        }

        for (minutes in timers) {
            if (minutes <= 0) continue
            val offsetMs = minutes * 60_000L

            for (p in periods) {
                val offAt = p.timeFrom * 1000L - offsetMs
                if (offAt > now) {
                    scheduleOne(context, am, widgetId, reqCode++, offAt,
                        "Скоро вимкнення", "Світло вимкнеться через $minutes хв")
                }
                val onAt = p.timeTo * 1000L - offsetMs
                if (onAt > now) {
                    scheduleOne(context, am, widgetId, reqCode++, onAt,
                        "Скоро увімкнення", "Світло з’явиться через $minutes хв")
                }
            }
        }
    }

    private fun scheduleOne(
        context: Context, am: AlarmManager, widgetId: Int, requestCode: Int,
        triggerAt: Long, title: String, body: String
    ) {
        val intent = Intent(context, OutageAlarmReceiver::class.java).apply {
            putExtra("widgetId", widgetId)
            putExtra("title", title)
            putExtra("body", body)
        }
        val pi = PendingIntent.getBroadcast(context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            else am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } catch (_: Exception) {}
    }

    fun cancel(context: Context, widgetId: Int) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        for (i in 0 until 40) {
            val pi = PendingIntent.getBroadcast(
                context, 10000 + widgetId * 40 + i,
                Intent(context, OutageAlarmReceiver::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            am.cancel(pi)
        }
    }

    fun showNotification(context: Context, widgetId: Int, title: String, body: String) {
        ensureChannel(context)

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        if (WidgetPrefs.notifySound(context, widgetId)) {
            builder.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
        } else {
            builder.setSound(null)
        }

        if (WidgetPrefs.notifyVibrate(context, widgetId)) {
            builder.setVibrate(longArrayOf(0, 300, 150, 300))
            try {
                val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator
                } else {
                    @Suppress("DEPRECATION")
                    context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(longArrayOf(0, 300, 150, 300), -1)
                }
            } catch (_: Exception) {}
        }

        try {
            NotificationManagerCompat.from(context).notify(20000 + widgetId, builder.build())
        } catch (_: Exception) {}
    }
}
