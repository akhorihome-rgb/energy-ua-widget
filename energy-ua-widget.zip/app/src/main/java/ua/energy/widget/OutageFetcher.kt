package ua.energy.widget

import java.util.Calendar
import java.util.TimeZone

data class FetchResult(
    val periods: List<OutagePeriod>,
    val fromCache: Boolean = false,
    val debug: String = ""
)

object OutageFetcher {

    /**
     * Полностью оффлайн. Онлайн-запросы удалены.
     * Возвращает периоды только из ручного ввода (WidgetPrefs).
     */
    fun fetchTodayPeriods(
        context: android.content.Context? = null,
        widgetId: Int = 0,
        city: String = "",
        queue: String = "5.2"
    ): FetchResult {
        if (context == null) {
            return FetchResult(emptyList(), false, "немає контексту")
        }
        val today = todayKyivDate()
        val manualDate = WidgetPrefs.manualDate(context, widgetId)
        val raw = WidgetPrefs.manualPeriods(context, widgetId)

        if (raw.isEmpty()) {
            return FetchResult(emptyList(), false, "немає графіка")
        }
        if (manualDate != today) {
            return FetchResult(emptyList(), false, "графік на $manualDate (потрібен сьогодні)")
        }

        val periods = parseManualPeriods(raw)
        return FetchResult(periods, true, "офлайн")
    }

    /** Парсит список "HH:MM-HH:MM" в OutagePeriod на сегодня (Киев). */
    fun parseManualPeriods(raw: List<String>): List<OutagePeriod> {
        val dayStart = kyivDayStartSec()
        val result = mutableListOf<OutagePeriod>()
        for (s in raw) {
            val parts = s.split("-")
            if (parts.size != 2) continue
            val fromSec = parseHm(parts[0].trim())
            val toSec = parseHm(parts[1].trim())
            if (fromSec == null || toSec == null) continue
            if (toSec <= fromSec) continue
            result.add(OutagePeriod(dayStart + fromSec, dayStart + toSec))
        }
        return result.sortedBy { it.timeFrom }
    }

    private fun parseHm(hm: String): Long? {
        val m = Regex("""^(\d{1,2}):(\d{2})$""").matchEntire(hm) ?: return null
        val h = m.groupValues[1].toIntOrNull() ?: return null
        val min = m.groupValues[2].toIntOrNull() ?: return null
        if (h !in 0..23 || min !in 0..59) return null
        return h * 3600L + min * 60L
    }

    fun kyivDayStartSec(): Long {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Europe/Kyiv"))
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis / 1000
    }

    private fun todayKyivDate(): String {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Europe/Kyiv"))
        val y = cal.get(Calendar.YEAR)
        val m = cal.get(Calendar.MONTH) + 1
        val d = cal.get(Calendar.DAY_OF_MONTH)
        return "%04d-%02d-%02d".format(y, m, d)
    }

    
}
