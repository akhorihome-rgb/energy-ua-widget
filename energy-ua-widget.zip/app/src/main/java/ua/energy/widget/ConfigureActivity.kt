package ua.energy.widget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class ConfigureActivity : Activity() {

    private var appWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private val sizes = listOf(10f, 12f, 14f, 16f, 18f, 20f, 22f, 24f, 28f)
    private val gaps = listOf(0, 2, 4, 6, 8, 10, 12, 16)
    private val notifyOptions = listOf(0, 5, 10, 15, 30, 60)
    private val alignOptions = listOf("Ліворуч", "По центру", "Праворуч")
    private val themeOptions = listOf("Темна", "Світла")
    private val colors = listOf(
        "Білий" to 0xFFFFFFFF.toInt(),
        "Жовтий" to 0xFFFFCC00.toInt(),
        "Світло-сірий" to 0xFFDDDDDD.toInt(),
        "Сірий" to 0xFF888888.toInt(),
        "Зелений" to 0xFF4CAF50.toInt(),
        "Червоний" to 0xFFF44336.toInt(),
        "Блакитний" to 0xFF03A9F4.toInt(),
        "Помаранчевий" to 0xFFFF9800.toInt()
    )
    private val bgColors = listOf(
        "Темно-синій" to 0xFF1A1A2E.toInt(),
        "Чорний" to 0xFF000000.toInt(),
        "Темно-сірий" to 0xFF212121.toInt(),
        "Темно-зелений" to 0xFF1B5E20.toInt(),
        "Темно-червоний" to 0xFF3E0000.toInt(),
        "Білий" to 0xFFFFFFFF.toInt(),
        "Світло-сірий" to 0xFFF5F5F5.toInt()
    )
    private val borderColors = listOf(
        "Зелений" to 0xFF4CAF50.toInt(),
        "Білий" to 0xFFFFFFFF.toInt(),
        "Жовтий" to 0xFFFFCC00.toInt(),
        "Сірий" to 0xFF888888.toInt(),
        "Червоний" to 0xFFF44336.toInt(),
        "Блакитний" to 0xFF03A9F4.toInt()
    )

    private lateinit var etFrom: Array<EditText>
    private lateinit var etTo: Array<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_CANCELED)
        setContentView(R.layout.activity_configure)

        appWidgetId = intent?.extras?.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
            ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (appWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return }

        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
            }
        }

        etFrom = arrayOf(
            findViewById(R.id.et_from_1), findViewById(R.id.et_from_2), findViewById(R.id.et_from_3),
            findViewById(R.id.et_from_4), findViewById(R.id.et_from_5), findViewById(R.id.et_from_6),
            findViewById(R.id.et_from_7)
        )
        etTo = arrayOf(
            findViewById(R.id.et_to_1), findViewById(R.id.et_to_2), findViewById(R.id.et_to_3),
            findViewById(R.id.et_to_4), findViewById(R.id.et_to_5), findViewById(R.id.et_to_6),
            findViewById(R.id.et_to_7)
        )

        val today = todayKyiv()
        if (WidgetPrefs.manualDate(this, appWidgetId) == today) {
            WidgetPrefs.manualPeriods(this, appWidgetId).forEachIndexed { i, s ->
                if (i < 7) {
                    val parts = s.split("-")
                    if (parts.size == 2) {
                        etFrom[i].setText(parts[0].trim())
                        etTo[i].setText(parts[1].trim())
                    }
                }
            }
        }

        findViewById<EditText>(R.id.et_label_off).setText(WidgetPrefs.labelUntilOff(this, appWidgetId))
        findViewById<EditText>(R.id.et_label_on).setText(WidgetPrefs.labelUntilOn(this, appWidgetId))

        val spTheme = findViewById<Spinner>(R.id.spinner_theme)
        val spBg = findViewById<Spinner>(R.id.spinner_bg_color)
        val spAutoOn = findViewById<Spinner>(R.id.spinner_auto_on)
        val spAutoOff = findViewById<Spinner>(R.id.spinner_auto_off)
        val spAlign = findViewById<Spinner>(R.id.spinner_align)
        val spGap = findViewById<Spinner>(R.id.spinner_gap)
        val spBorderColor = findViewById<Spinner>(R.id.spinner_border_color)
        val spNotify = findViewById<Spinner>(R.id.spinner_notify)
        val spCT = findViewById<Spinner>(R.id.spinner_c_timer)
        val spCP = findViewById<Spinner>(R.id.spinner_c_periods)
        val spSI = findViewById<Spinner>(R.id.spinner_s_icon)
        val spST = findViewById<Spinner>(R.id.spinner_s_timer)
        val spSP = findViewById<Spinner>(R.id.spinner_s_periods)

        val cbIcon = findViewById<CheckBox>(R.id.cb_icon)
        val cbT = findViewById<CheckBox>(R.id.cb_timer)
        val cbP = findViewById<CheckBox>(R.id.cb_periods)
        val cbBorder = findViewById<CheckBox>(R.id.cb_border)
        val cbAutoBg = findViewById<CheckBox>(R.id.cb_auto_bg)
        val cbOnlyNearest = findViewById<CheckBox>(R.id.cb_only_nearest)
        val cbSound = findViewById<CheckBox>(R.id.cb_sound)
        val cbVibrate = findViewById<CheckBox>(R.id.cb_vibrate)

        fun ca() = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, colors.map { it.first })
        fun sa() = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sizes.map { "${it.toInt()} sp" })
        fun ba() = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, bgColors.map { it.first })

        spTheme.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, themeOptions)
        spBg.adapter = ba()
        spAutoOn.adapter = ba()
        spAutoOff.adapter = ba()
        spAlign.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, alignOptions)
        spGap.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, gaps.map { "$it dp" })
        spBorderColor.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, borderColors.map { it.first })
        spNotify.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            notifyOptions.map { if (it == 0) "Вимкнено" else "За $it хв" })
        spCT.adapter = ca(); spCP.adapter = ca()
        spSI.adapter = sa(); spST.adapter = sa(); spSP.adapter = sa()

        fun idxC(c: Int, list: List<Pair<String, Int>>) = list.indexOfFirst { it.second == c }.coerceAtLeast(0)
        fun idxS(s: Float) = sizes.indexOfFirst { it == s }.let { if (it >= 0) it else 2 }

        spTheme.setSelection(WidgetPrefs.theme(this, appWidgetId).coerceIn(0, 1))
        spBg.setSelection(idxC(WidgetPrefs.bgColor(this, appWidgetId), bgColors))
        spAutoOn.setSelection(idxC(WidgetPrefs.autoBgOnColor(this, appWidgetId), bgColors))
        spAutoOff.setSelection(idxC(WidgetPrefs.autoBgOffColor(this, appWidgetId), bgColors))
        spAlign.setSelection(WidgetPrefs.align(this, appWidgetId).coerceIn(0, 2))
        spGap.setSelection(gaps.indexOf(WidgetPrefs.rowGapDp(this, appWidgetId)).coerceAtLeast(0))
        spBorderColor.setSelection(idxC(WidgetPrefs.borderColor(this, appWidgetId), borderColors))
        spNotify.setSelection(notifyOptions.indexOf(WidgetPrefs.notifyMinutes(this, appWidgetId)).coerceAtLeast(0))
        spCT.setSelection(idxC(WidgetPrefs.colorTimer(this, appWidgetId), colors))
        spCP.setSelection(idxC(WidgetPrefs.colorPeriods(this, appWidgetId), colors))
        spSI.setSelection(idxS(WidgetPrefs.sizeIcon(this, appWidgetId)))
        spST.setSelection(idxS(WidgetPrefs.sizeTimer(this, appWidgetId)))
        spSP.setSelection(idxS(WidgetPrefs.sizePeriods(this, appWidgetId)))

        cbIcon.isChecked = WidgetPrefs.showIcon(this, appWidgetId)
        cbT.isChecked = WidgetPrefs.showTimer(this, appWidgetId)
        cbP.isChecked = WidgetPrefs.showPeriods(this, appWidgetId)
        cbBorder.isChecked = WidgetPrefs.showBorder(this, appWidgetId)
        cbAutoBg.isChecked = WidgetPrefs.autoBg(this, appWidgetId)
        cbOnlyNearest.isChecked = WidgetPrefs.onlyNearest(this, appWidgetId)
        cbSound.isChecked = WidgetPrefs.notifySound(this, appWidgetId)
        cbVibrate.isChecked = WidgetPrefs.notifyVibrate(this, appWidgetId)

        findViewById<Button>(R.id.btn_save).setOnClickListener {
            val labelOff = findViewById<EditText>(R.id.et_label_off).text.toString().ifBlank { "До вимкнення:" }
            val labelOn = findViewById<EditText>(R.id.et_label_on).text.toString().ifBlank { "До увімкнення:" }

            WidgetPrefs.save(
                this, appWidgetId,
                bgColors[spBg.selectedItemPosition].second,
                gaps[spGap.selectedItemPosition],
                cbIcon.isChecked, cbT.isChecked, cbP.isChecked,
                colors[spCT.selectedItemPosition].second,
                colors[spCP.selectedItemPosition].second,
                sizes[spSI.selectedItemPosition],
                sizes[spST.selectedItemPosition],
                sizes[spSP.selectedItemPosition],
                notifyOptions[spNotify.selectedItemPosition],
                spAlign.selectedItemPosition,
                cbBorder.isChecked,
                borderColors[spBorderColor.selectedItemPosition].second,
                labelOn, labelOff,
                cbAutoBg.isChecked,
                bgColors[spAutoOn.selectedItemPosition].second,
                bgColors[spAutoOff.selectedItemPosition].second,
                cbOnlyNearest.isChecked,
                spTheme.selectedItemPosition,
                cbSound.isChecked,
                cbVibrate.isChecked
            )

            val periods = mutableListOf<String>()
            for (i in 0 until 7) {
                val f = etFrom[i].text.toString().trim()
                val t = etTo[i].text.toString().trim()
                if (f.isNotEmpty() && t.isNotEmpty()) periods.add("$f-$t")
            }
            WidgetPrefs.setManualPeriods(this, appWidgetId, periods, todayKyiv())

            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId))
            EnergyWidgetProvider.updateAppWidget(this, AppWidgetManager.getInstance(this), appWidgetId)
            Toast.makeText(this, "Збережено", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun todayKyiv(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("Europe/Kyiv")
        return sdf.format(Date())
    }
}
